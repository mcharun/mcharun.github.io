ライセンス
CC BY 4.0　
簡単にいえば、著作表示さえすれば基本自由に使えるライセンスです。
詳細はこちら　https://creativecommons.org/licenses/by/4.0/deed.ja

使い方
こちらのページを見てください
https://mcharun.github.io/acp.html

2020/5/2
むちゃるん Some rights reserved